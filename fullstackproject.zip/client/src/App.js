import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './component/header';
import Login from './component/login';
import Signup from './component/signup';
import Authcheck from './component/authcheck';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route exact path="/login" element={<Login />} ></Route>
          <Route exact path="/signup" element={<Signup />} ></Route>
          <Route exact path="/activity" element={<Authcheck><Header /></Authcheck>}></Route>
        </Routes>
      </BrowserRouter>
    </div >
  );
}

export default App;

import React from 'react'
import { Navigate } from "react-router-dom"
function Authcheck({ children }) {
        const token = localStorage.getItem("token");

        return (
                <div>
                        {token.length ? children : <Navigate to="/login" />}
                </div>
        )
}

export default Authcheck

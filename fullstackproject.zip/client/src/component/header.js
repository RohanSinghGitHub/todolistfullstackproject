import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import './header.css'

function Header() {

        const [check, setCheck] = useState(false)
        const [addactivityshow, setAddactivityshow] = useState(false);
        const [activity, setActivity] = useState([]);
        const [time, setTime] = useState([]);
        const usernamepresent = localStorage.userdetail.split('"');
        const navigate = useNavigate();
        const [activityadd, setActivityadd] = useState({ activityname: "" });
        const handleactivity = async (e) => {
                e.preventDefault();
                axios({
                        url: "http://localhost:5007/add/addactivity",
                        method: "POST",
                        headers: {

                        },
                        data: activityadd,
                }).then((res) => {
                        //console.log(res);
                        setCheck(false)
                        setActivityadd("")
                }).catch((err) => {
                        console.log(err)
                });
        }







        const actfetch = () => {
                axios({
                        url: "http://localhost:5007/add/getactivity",
                        method: "GET"
                }).then((res) => {
                        setActivity(res.data.activitydata)

                }).catch((err) => { console.log(err) })
        }
        useEffect(() => {
                actfetch();
        }, [handleactivity])

        const cleardata = () => {
                localStorage.setItem("token", "");
                navigate("/login")
        }
        const addactivityhandle = () => {
                setCheck(true)
        }
        const handlevalue = (e) => {

        }
        const handlestartevent = (e) => {

        }
        const endactivity = (e) => {

        }
        const pauseactivity = () => {

        }
        return (
                <div className='allpage'>
                        <div className="header">
                                <h1>{usernamepresent[3]}</h1>
                        </div>
                        <div className="sidebar">
                                <h3>Todo list</h3>
                                <h3>History</h3>
                                <ul className='historyitem'>

                                </ul>
                                <h3 className='logout' onClick={cleardata}>Logout</h3>
                        </div>
                        <div className="maincontent">
                                <button className='btnadd' onClick={addactivityhandle}>Add new activity</button>
                                <div className="table">
                                        <table className='table' >
                                                <thead >
                                                        <tr >
                                                                <th className='tadjust' >
                                                                        Activity
                                                                </th>
                                                                <th className='tadjust'>
                                                                        Status
                                                                </th >
                                                                <th className='tadjust'>
                                                                        Time Taken <br /> (Hrs: Mins: sec)
                                                                </th>
                                                                <th className='tadjust'>
                                                                        Action
                                                                </th>

                                                        </tr>
                                                </thead>
                                                <tbody>
                                                        {
                                                                activity.map((item, index) => {

                                                                        return (
                                                                                <tr>
                                                                                        <td key={item.activityname} title={item.activityname} onMouseEnter={(e) => { handlevalue(e.target.title) }} className='tadjust'>{item.activityname}</td>
                                                                                        <td key={item.activitystatus} title={item.activityname} className='tadjust'>{item.activitystatus}</td>
                                                                                        <td key={item.activitytime} title={item.activityname} className='tadjust'>{item.activitytime}</td>
                                                                                        <td key={item.activityaction} className='tadjust'>{item.activityaction === "start" ? <button title={item._id} onClick={(e) => { handlestartevent(e.target.title) }} >{item.activityaction}</button> : <><button title={item._id} onClick={(e) => { endactivity(e.target.title) }}>END</button><button onClick={pauseactivity}>pause</button></>}</td>

                                                                                </tr>
                                                                        )
                                                                })
                                                        }
                                                </tbody>
                                        </table>
                                </div>
                        </div>
                        <div className={check ? "show" : "hide"}>
                                <form onSubmit={(e) => { handleactivity(e) }}>
                                        <input type="text" placeholder='Activity Name' onChange={(e) => { setActivityadd({ "activityname": e.target.value, "activitystatus": "pending", "activitytime": "00:00:00", "activityaction": "start" }) }} />
                                        <input type="submit" value="Add ACTIVITY" />
                                </form>
                        </div>


                </div>
        )
}

export default Header
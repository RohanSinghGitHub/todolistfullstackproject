import React from 'react'
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

import "./login.js"
function Signup() {
        const [username, setUsername] = useState("");
        const [password, setPassword] = useState("");
        const navigate = useNavigate()
        const [cnfpassword, setCnfpassword] = useState("");
        const [signupdata, setSignupdata] = useState({ username: "", password: "", cnfpassword: "" });
        const handleRegister = async (e) => {
                e.preventDefault();
                setSignupdata({ "username": username, "password": password, "cnfpassword": cnfpassword })
                await axios({
                        url: "http://localhost:5007/user/signup",
                        method: "POST",
                        headers: {

                        },
                        data: signupdata
                }).then((res) => {
                        alert("Successfully Signedup, press OK to redirect to the Login Page");
                        navigate("/login")
                }).catch((err) => {
                        console.log(err)
                })
        }
        const handleUsername = (e) => {
                setUsername(e)
        }
        const handlePassword = (e) => {
                setPassword(e)
        }
        const handleCnfpassword = (e) => {
                setCnfpassword(e)
        }

        const handlelogin = () => {
                navigate("/activity")
        }

        return (
                <div className='cardlogin'>
                        <h1>Register</h1>
                        <form onSubmit={handleRegister}>
                                <input type="text" placeholder='username' onChange={(e) => { handleUsername(e.target.value) }} />
                                <input type="password" placeholder='password' onChange={(e) => { handlePassword(e.target.value) }} />
                                <input type="password" placeholder='Confirm Password' onChange={(e) => { handleCnfpassword(e.target.value) }} />
                                <input type="submit" className='loginbtn' value="Register" />
                                <input type="submit" onClick={handlelogin} className='pas' value="Login?" />
                        </form>

                </div>
        )
}

export default Signup

import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Header from './header';
import "./login.css"
function Login() {
        const [username, setUsername] = useState("");
        const [password, setPassword] = useState("");
        const [logindata, setLogindata] = useState({});

        const navigate = useNavigate();
        const handleLogin = (e) => {
                e.preventDefault();
                setLogindata({ "username": username, "password": password });
                axios({
                        url: "http://localhost:5007/user/login",
                        method: 'POST',
                        headers: {},
                        data: logindata
                }).then((res) => {
                        console.log(res.data)
                        localStorage.setItem("token", res.data)
                        localStorage.setItem("userdetail", res.config.data)
                        navigate("/activity")
                        console.log(res.config.data)
                }).catch((err) => {
                        console.log(err)
                })

        }
        const handleUsername = (e) => {
                setUsername(e)
        }
        const handlePassword = (e) => {
                setPassword(e)
        }

        const handlepass = () => {
                navigate("/signup")
        }


        return (
                <div className='cardlogin'>
                        <h1>Member Login</h1>
                        <form onSubmit={handleLogin}>
                                <input type="text" placeholder='username' onChange={(e) => { handleUsername(e.target.value) }} />
                                <input type="password" placeholder='password' onChange={(e) => { handlePassword(e.target.value) }} />
                                <input type="submit" className='loginbtn' value="Login" />
                                <input type="submit" onClick={handlepass} className='pas' value="Forgot password?" />
                        </form>

                </div>
        )
}

export default Login
